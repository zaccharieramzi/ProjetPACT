package moduleIntegration;

public class ClassificationControleur {
//test
}
