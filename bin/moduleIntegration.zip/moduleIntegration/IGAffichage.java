package moduleIntegration;

public class IGAffichage {

}
