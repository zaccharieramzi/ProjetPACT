package moduleIntegration;

public class IGControleur {

}
