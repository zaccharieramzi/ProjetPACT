package moduleIntegration;

public class DescripteurClassification {

}
